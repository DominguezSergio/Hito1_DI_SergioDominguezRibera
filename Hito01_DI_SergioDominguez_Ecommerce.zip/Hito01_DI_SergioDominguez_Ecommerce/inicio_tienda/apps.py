from django.apps import AppConfig


class InicioTiendaConfig(AppConfig):
    name = 'inicio_tienda'
