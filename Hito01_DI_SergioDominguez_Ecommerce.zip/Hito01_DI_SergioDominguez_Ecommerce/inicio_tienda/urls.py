from django.urls import path
from inicio_tienda import views

urlpatterns = [
    path('', views.inicio_tienda, name='inicio_tienda'),
]